require 'test_helper'

class AddUserToProfileTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
